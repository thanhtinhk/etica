#!/bin/bash

./onezerominer -a dynex -w Xwoe3a8eoCeZ9kBPvu3dAW2JinMRvtNTRdHdwynfE43JQBLxtRrByzpTDgnM4X3qjsZrgfgojbnGEZRVepMAQYce28be1eDb3 -o dnx.eu.neuropool.net:19330,pool.deepminerz.com:3333 -p x